from flask import Flask, request, jsonify
from flask_cors import CORS
import subprocess
from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

app = Flask(__name__)
CORS(app)

def validate_input(data):
    """Validate incoming request data."""
    if not data or 'message' not in data:
        return False, "No message provided"
    if not isinstance(data['message'], str):
        return False, "Message must be a string"
    if len(data['message']) > 1000:
        return False, "Message too long"
    return True, None

@app.route('/chat', methods=['POST'])
def chat():
    """Handle chat requests."""
    try:
        # Validate input
        is_valid, error = validate_input(request.json)
        if not is_valid:
            return jsonify({"error": error}), 400

        # Get user input
        user_input = request.json['message']

        # Interact with Ollama
        result = subprocess.run(
            ["ollama", "run", "codellama", user_input],
            capture_output=True,
            text=True,
            timeout=30
        )

        # Process the response
        response = result.stdout
        code = ""
        explanation = ""

        if "```" in response:
            parts = response.split("```")
            explanation = parts[0].strip()
            code = parts[1].strip() if len(parts) > 1 else ""
        else:
            explanation = response.strip()

        return jsonify({
            "code": code,
            "explanation": explanation
        })

    except subprocess.TimeoutExpired:
        return jsonify({"error": "Request timed out"}), 504
    except Exception as e:
        app.logger.error(f"Error processing request: {str(e)}")
        return jsonify({"error": "Internal server error"}), 500

if __name__ == '__main__':
    port = int(os.getenv('PORT', 5000))
    debug = os.getenv('FLASK_DEBUG', 'false').lower() == 'true'
    app.run(host='0.0.0.0', port=port, debug=debug)