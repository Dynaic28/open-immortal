<!-- markdownlint-disable -->
# Immortal™ Chat

![Immortal Chat](https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=1200&h=400&fit=crop)

A next-generation AI chat interface with stunning 3D visuals and real-time code sharing capabilities.

## ✨ Features

- 🎨 Beautiful shader-based background animations
- 💬 Real-time chat with AI assistance
- 🔥 Code syntax highlighting and copying
- 🌓 Glass-morphic UI elements
- 📱 Fully responsive design
- ⚡ Optimized performance
- 🔒 Type-safe implementation

## 🚀 Quick Start

### Prerequisites

- Node.js 16+
- Python 3.8+
- Ollama (for AI backend)

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/immortal-chat.git
cd immortal-chat
```

2. Install frontend dependencies:
```bash
npm install
```

3. Install backend dependencies:
```bash
pip install flask flask-cors
```

### Development

1. Start the Flask backend:
```bash
python app.py
```

2. Start the frontend development server:
```bash
npm run dev
```

3. Open your browser and navigate to `http://localhost:5173`

## 🏗️ Project Structure

```
immortal-chat/
├── src/
│   ├── components/        # React components
│   ├── hooks/            # Custom React hooks
│   ├── services/         # API services
│   ├── shaders/          # GLSL shaders
│   ├── store/            # State management
│   ├── types/            # TypeScript definitions
│   └── utils/            # Utility functions
└── backend/              # Python Flask backend
```

## 🔧 Configuration

The application can be configured through environment variables:

```env
VITE_API_URL=http://localhost:5000
VITE_ENABLE_DEBUG=false
```

## 🛡️ Security

- Input sanitization
- Rate limiting
- CORS protection
- Error handling

## 📝 API Documentation

### POST /api/chat

Send a message to the AI.

**Request:**
```json
{
  "message": "string"
}
```

**Response:**
```json
{
  "explanation": "string",
  "code": "string"
}
```

## 🎨 Styling Guidelines

- Use Tailwind CSS for styling
- Follow glass-morphic design principles
- Maintain consistent color scheme:
  - Primary: #0ff (Cyan)
  - Secondary: #f0f (Magenta)
  - Background: #111 (Dark)
  - Text: #fff (White)

## 📄 License

Copyright © 2024 Immortal™ Chat. All rights reserved.

---

<sub>Made with ❤️ by Immortal™ Team</sub>