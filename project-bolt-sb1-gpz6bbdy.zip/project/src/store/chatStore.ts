import { create } from 'zustand';
import { Message, User } from '../types/message';

interface ChatState {
  messages: Message[];
  users: User[];
  currentUser: User | null;
  isTyping: boolean;
  addMessage: (message: Message) => void;
  setTyping: (typing: boolean) => void;
}

export const useChatStore = create<ChatState>((set) => ({
  messages: [],
  users: [
    {
      id: '1',
      name: 'Alice',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
      isOnline: true,
    },
    {
      id: '2',
      name: 'Bob',
      avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=150',
      isOnline: true,
    },
  ],
  currentUser: {
    id: '1',
    name: 'Alice',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
    isOnline: true,
  },
  isTyping: false,
  addMessage: (message) =>
    set((state) => ({ messages: [...state.messages, message] })),
  setTyping: (typing) => set({ isTyping: typing }),
}));