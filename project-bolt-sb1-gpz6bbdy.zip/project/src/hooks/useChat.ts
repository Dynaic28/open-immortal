import { useState } from 'react';
import { useChatStore } from '../store/chatStore';
import { sendMessage } from '../services/api';

export function useChat() {
  const [isLoading, setIsLoading] = useState(false);
  const { addMessage, currentUser, setTyping } = useChatStore();

  const handleSendMessage = async (content: string) => {
    if (!content.trim() || !currentUser) return;

    try {
      setIsLoading(true);
      setTyping(true);

      // Add user message
      addMessage({
        id: Date.now().toString(),
        content,
        sender: currentUser.id,
        timestamp: new Date(),
        isRead: false,
      });

      // Get AI response
      const response = await sendMessage(content);

      // Add AI response
      addMessage({
        id: (Date.now() + 1).toString(),
        content: response.explanation,
        sender: 'ai',
        timestamp: new Date(),
        isRead: true,
        code: response.code,
      });
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setIsLoading(false);
      setTyping(false);
    }
  };

  return {
    isLoading,
    handleSendMessage,
  };
}