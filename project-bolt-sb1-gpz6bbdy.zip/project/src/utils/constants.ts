export const APP_CONFIG = {
  API_URL: import.meta.env.VITE_API_URL || 'http://localhost:5000',
  DEBUG: import.meta.env.VITE_ENABLE_DEBUG === 'true',
  APP_NAME: 'Immortal™ Chat',
  VERSION: '1.0.0',
} as const;

export const THEME = {
  colors: {
    primary: '#0ff',
    secondary: '#f0f',
    background: '#111',
    text: '#fff',
  },
} as const;