import { Canvas } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import { ShaderBackground } from './ShaderBackground';

export function ThreeScene() {
  return (
    <div className="fixed inset-0 -z-10">
      <Canvas>
        <ShaderBackground />
        <OrbitControls enableZoom={false} enablePan={false} />
      </Canvas>
    </div>
  );
}