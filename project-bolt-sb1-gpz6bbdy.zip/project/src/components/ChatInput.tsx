import { useState, KeyboardEvent } from 'react';
import { Send } from 'lucide-react';
import { useChat } from '../hooks/useChat';

export function ChatInput() {
  const [message, setMessage] = useState('');
  const { isLoading, handleSendMessage } = useChat();

  const handleSubmit = () => {
    if (!message.trim() || isLoading) return;
    handleSendMessage(message);
    setMessage('');
  };

  const handleKeyPress = (e: KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="p-4 bg-gray-900/50 backdrop-blur-lg border-t border-gray-800">
      <div className="flex gap-2">
        <textarea
          className="flex-1 bg-gray-800/50 text-white rounded-lg p-3 resize-none focus:outline-none focus:ring-2 focus:ring-cyan-500"
          placeholder="Ask me anything about programming..."
          rows={1}
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyPress={handleKeyPress}
          disabled={isLoading}
        />
        <button
          onClick={handleSubmit}
          disabled={isLoading}
          className={`p-3 bg-cyan-500 text-white rounded-lg transition-colors ${
            isLoading ? 'opacity-50' : 'hover:bg-cyan-600'
          }`}
        >
          <Send className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}