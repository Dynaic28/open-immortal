import { Message } from '../types/message';
import { useChatStore } from '../store/chatStore';
import { Check, CheckCheck } from 'lucide-react';
import { CodeBlock } from './CodeBlock';

interface ChatBubbleProps {
  message: Message;
}

export function ChatBubble({ message }: ChatBubbleProps) {
  const currentUser = useChatStore((state) => state.currentUser);
  const isSender = currentUser?.id === message.sender;
  const isAI = message.sender === 'ai';

  return (
    <div
      className={`flex ${
        isSender ? 'justify-end' : 'justify-start'
      } mb-4 animate-fade-in`}
    >
      <div
        className={`max-w-[80%] px-4 py-2 rounded-2xl ${
          isSender
            ? 'bg-cyan-500/20 backdrop-blur-sm text-white'
            : isAI
            ? 'bg-fuchsia-500/20 backdrop-blur-sm text-white'
            : 'bg-gray-700/20 backdrop-blur-sm text-white'
        }`}
      >
        <p className="text-sm whitespace-pre-wrap">{message.content}</p>
        {message.code && <CodeBlock code={message.code} />}
        <div className="flex items-center justify-end gap-1 mt-1">
          <span className="text-xs opacity-70">
            {new Date(message.timestamp).toLocaleTimeString()}
          </span>
          {isSender && (
            <span className="text-xs">
              {message.isRead ? (
                <CheckCheck className="w-4 h-4" />
              ) : (
                <Check className="w-4 h-4" />
              )}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}