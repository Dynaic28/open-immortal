import { ThreeScene } from './ThreeScene';
import { ChatBubble } from './ChatBubble';
import { ChatInput } from './ChatInput';
import { useChatStore } from '../store/chatStore';
import { MessageSquare } from 'lucide-react';

export function ChatInterface() {
  const { messages, users, isTyping } = useChatStore();

  return (
    <div className="relative min-h-screen bg-gray-900 text-white">
      <ThreeScene />
      
      <div className="container mx-auto max-w-4xl h-screen flex flex-col">
        <header className="p-4 bg-gray-900/50 backdrop-blur-lg border-b border-gray-800">
          <div className="flex items-center gap-4">
            <MessageSquare className="w-8 h-8 text-cyan-500" />
            <h1 className="text-2xl font-bold bg-gradient-to-r from-cyan-500 to-fuchsia-500 bg-clip-text text-transparent">
              Immortal™ Chat
            </h1>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message) => (
            <ChatBubble key={message.id} message={message} />
          ))}
          {isTyping && (
            <div className="flex gap-2 text-gray-400">
              <span className="animate-bounce">•</span>
              <span className="animate-bounce delay-100">•</span>
              <span className="animate-bounce delay-200">•</span>
            </div>
          )}
        </div>

        <ChatInput />
      </div>
    </div>
  );
}