import { ChatResponse } from '../types/api';
import { APP_CONFIG } from '../utils/constants';
import { APIError } from '../utils/errors';

export async function sendMessage(message: string): Promise<ChatResponse> {
  try {
    const response = await fetch(`${APP_CONFIG.API_URL}/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ message }),
    });

    if (!response.ok) {
      throw new APIError('Failed to send message', response.status);
    }

    return await response.json();
  } catch (error) {
    if (APP_CONFIG.DEBUG) {
      console.error('Error sending message:', error);
    }
    throw error;
  }
}