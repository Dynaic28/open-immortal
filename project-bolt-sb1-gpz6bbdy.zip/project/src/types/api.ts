export interface ChatResponse {
  code: string;
  explanation: string;
  error?: string;
}