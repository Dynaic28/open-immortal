export interface Keyframes {
  [key: string]: string;
}

export type KeyframesDefinition = (strings: TemplateStringsArray, ...args: any[]) => string;