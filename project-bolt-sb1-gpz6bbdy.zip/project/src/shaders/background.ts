export const vertexShader = `
varying vec2 vUv;
varying vec3 vPosition;

void main() {
  vUv = uv;
  vPosition = position;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}`;

export const fragmentShader = `
uniform float uTime;
varying vec2 vUv;

#define PI 3.14159265359

// Noise function
float noise(vec2 p) {
  return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

void main() {
  vec2 uv = vUv;
  
  // Create a grid effect
  vec2 grid = fract(uv * 10.0);
  float gridLines = step(0.95, grid.x) + step(0.95, grid.y);
  
  // Create moving waves
  float wave = sin(uv.x * 10.0 + uTime) * 0.5 + 0.5;
  wave *= sin(uv.y * 8.0 + uTime * 0.5) * 0.5 + 0.5;
  
  // Add some noise
  float n = noise(uv * 2.0 + uTime * 0.1);
  
  // Combine effects
  vec3 color1 = vec3(0.0, 1.0, 1.0); // Cyan
  vec3 color2 = vec3(1.0, 0.0, 1.0); // Magenta
  vec3 finalColor = mix(color1, color2, wave + n * 0.2);
  
  // Add grid lines
  finalColor += vec3(gridLines) * 0.1;
  
  gl_FragColor = vec4(finalColor * 0.5, 0.2);
}`;